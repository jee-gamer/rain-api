# coding: utf-8

# flake8: noqa
from __future__ import absolute_import
# import models into model package
from swagger_server.models.annual_rainfall import AnnualRainfall
from swagger_server.models.basin import Basin
from swagger_server.models.monthly_average import MonthlyAverage
from swagger_server.models.station import Station
